import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import axios from 'axios'
import { toast } from 'react-toastify'
import { login } from '../../store/authSlice'
import api from '../../api'
const DEMOS = [
  { label: 'Admin',    email: 'admin@hrflow.com',    password: 'Admin@123!',    role: 'super_admin' },
  { label: 'Employee', email: 'employee@hrflow.com', password: 'Employee@123!', role: 'employee'    },
]

export default function LoginPage() {
  const [form, setForm]         = useState({ email: '', password: '' })
  const [show, setShow]         = useState(false)
  const [loading, setLoading]   = useState(false)
  const [selected, setSelected] = useState(null) // which demo button is active

  const dispatch = useDispatch()
  const navigate = useNavigate()

  // Click demo button → fill form + select it (click same again to deselect)
  const handleDemoClick = (demo) => {
    if (selected?.label === demo.label) {
      setSelected(null)
      setForm({ email: '', password: '' })
    } else {
      setSelected(demo)
      setForm({ email: demo.email, password: demo.password })
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await api.post('/api/auth/login', {
        email:    form.email,
        password: form.password,
        role:     selected?.role || null, // send selected role to API
      })
if (res.data?.status === 1 || res.data?.message === "Login successful") {
     
      

      localStorage.setItem('token', res.data.token)
      localStorage.setItem('user', JSON.stringify(res.data.user))
      localStorage.setItem('role',JSON.stringify(res.data.role))

         dispatch(login({
              user: res.data.user,
              role: res.data.role,
            }));

      toast.success(`Welcome, ${res.data.user.name}!`)
     const user = res.data.user
dispatch(login(user))

if (user.role === 'admin') {
  navigate('/dashborad')
} else {
  navigate('/employee')
}
}
    } catch (err) {
      const msg = err.response?.data?.message || 'Invalid email or password.'
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-vh-100 d-flex" style={{ background: '#0d1117' }}>

      {/* ── Left panel ───────────────────────────────────────────────── */}
      <div
        className="d-none d-lg-flex flex-column justify-content-between col-lg-6 p-5 position-relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #4c1d95 0%, #7c3aed 50%, #6d28d9 100%)' }}
      >
        <div style={{ position:'absolute', top:-100, left:-100, width:400, height:400, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }} />
        <div style={{ position:'absolute', bottom:-100, right:-100, width:400, height:400, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }} />

        <div className="position-relative">
          <div className="d-flex align-items-center gap-3 mb-5">
            <div className="d-flex align-items-center justify-content-center rounded-3 bg-white bg-opacity-25" style={{ width:48, height:48 }}>
              <i className="bi bi-shield-fill-check text-white fs-5" />
            </div>
            <span className="text-white fs-4 fw-bold">HRFlow</span>
          </div>
          <h2 className="text-white fw-bold mb-3" style={{ fontSize:'2.5rem', lineHeight:1.2 }}>
            Modern HR<br />Management<br />Platform
          </h2>
          <p className="text-white text-opacity-75 fs-6">
            Streamline your workforce with AI-powered insights, automated payroll, and comprehensive analytics.
          </p>
        </div>

        <div className="row g-3 position-relative">
          {[['10K+','Employees'],['50K+','AI Insights'],['99.9%','Accuracy'],['4.9★','Rating']].map(([v, l]) => (
            <div key={l} className="col-6">
              <div className="rounded-3 p-3" style={{ background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,0.2)' }}>
                <div className="text-white fw-bold fs-4">{v}</div>
                <div className="text-white text-opacity-75 small">{l}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Right panel ──────────────────────────────────────────────── */}
      <div className="col-12 col-lg-6 d-flex align-items-center justify-content-center p-4">
        <div style={{ width: '100%', maxWidth: 420 }}>

          {/* Mobile logo */}
          <div className="d-lg-none d-flex align-items-center gap-2 mb-4">
            <div className="avatar"><i className="bi bi-shield-fill-check" /></div>
            <span className="text-white fw-bold fs-5">HRFlow</span>
          </div>

          <h2 className="text-white fw-bold mb-1">Welcome back</h2>
          <p style={{ color: '#8b949e' }} className="mb-4">Sign in to your HR Management account</p>

          {/* Demo buttons — only one active at a time */}
          <div className="mb-4 p-3 rounded-3" style={{ background:'rgba(124,58,237,0.1)', border:'1px solid rgba(124,58,237,0.2)' }}>
            <p className="mb-2 small" style={{ color:'#8b949e' }}>
              <i className="bi bi-stars me-1" style={{ color:'#a78bfa' }} />
              Quick Demo Login
            </p>
            <div className="d-flex gap-2">
              {DEMOS.map(demo => {
                const isActive = selected?.label === demo.label
                return (
                  <button
                    key={demo.label}
                    type="button"
                    onClick={() => handleDemoClick(demo)}
                    style={{
                      background:   isActive ? '#7c3aed'                 : 'rgba(124,58,237,0.2)',
                      color:        isActive ? '#ffffff'                 : '#a78bfa',
                      border:       isActive ? '1px solid #7c3aed'       : '1px solid rgba(124,58,237,0.3)',
                      borderRadius: 8,
                      padding:      '6px 16px',
                      fontSize:     '0.875rem',
                      fontWeight:   isActive ? 600 : 400,
                      cursor:       'pointer',
                      transition:   'all 0.15s',
                    }}
                  >
                    {isActive && <i className="bi bi-check-lg me-1" />}
                    {demo.label}
                  </button>
                )
              })}
            </div>
            {selected && (
              <p className="mb-0 mt-2" style={{ color:'#a78bfa', fontSize:'0.75rem' }}>
                <i className="bi bi-info-circle me-1" />
                Logging in as <strong>{selected.label}</strong> · {selected.email}
              </p>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label" style={{ color:'#8b949e' }}>Email Address</label>
              <div className="input-group">
                <span className="input-group-text" style={{ background:'#21262d', border:'1px solid #30363d', color:'#8b949e' }}>
                  <i className="bi bi-envelope" />
                </span>
                <input
                  type="email"
                  className="form-control"
                  placeholder="you@company.com"
                  value={form.email}
                  onChange={e => { setForm({ ...form, email: e.target.value }); setSelected(null) }}
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label" style={{ color:'#8b949e' }}>Password</label>
              <div className="input-group">
                <span className="input-group-text" style={{ background:'#21262d', border:'1px solid #30363d', color:'#8b949e' }}>
                  <i className="bi bi-lock" />
                </span>
                <input
                  type={show ? 'text' : 'password'}
                  className="form-control"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => { setForm({ ...form, password: e.target.value }); setSelected(null) }}
                  required
                />
                <button
                  type="button"
                  className="input-group-text"
                  onClick={() => setShow(s => !s)}
                  style={{ background:'#21262d', border:'1px solid #30363d', color:'#8b949e', cursor:'pointer' }}
                >
                  <i className={`bi bi-${show ? 'eye-slash' : 'eye'}`} />
                </button>
              </div>
            </div>

            <div className="d-flex justify-content-end mb-4">
              <Link to="/forgot" style={{ color:'#a78bfa', textDecoration:'none', fontSize:'0.875rem' }}>
                Forgot password?
              </Link>
            </div>

            <button type="submit" className="btn btn-primary w-100 py-2 fw-semibold" disabled={loading}>
              {loading
                ? <><span className="spinner-border spinner-border-sm me-2" />Signing in...</>
                : 'Sign In'
              }
            </button>
          </form>

          <p className="text-center mt-4 small" style={{ color:'#8b949e' }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color:'#a78bfa', textDecoration:'none' }}>Create account</Link>
          </p>

        </div>
      </div>
    </div>
  )
}
