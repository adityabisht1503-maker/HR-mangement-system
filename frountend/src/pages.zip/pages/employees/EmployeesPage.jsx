import React, { useState, useEffect } from 'react'
import { useSelector } from 'react-redux'
import { employeeAPI, departmentAPI } from '../../services/api.js'
import toast from 'react-hot-toast'

// ─── helpers ─────────────────────────────────────────────────────────────────
const initials = (f, l) => `${f?.[0] || ''}${l?.[0] || ''}`.toUpperCase()
const fmt      = d => d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'

// ─── styles ──────────────────────────────────────────────────────────────────
const S = {
  page:       { fontFamily: "'DM Sans', sans-serif", color: '#e6edf3', padding: 0 },
  header:     { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' },
  title:      { margin: 0, fontSize: '1.5rem', fontWeight: 700, color: '#f0f6fc' },
  sub:        { margin: '0.2rem 0 0', fontSize: '0.82rem', color: '#6e7681' },

  grid4:      { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '1rem', marginBottom: '1.5rem' },
  statCard:   (accent, bg) => ({ background: '#161b22', border: '1px solid #21262d', borderTop: `2px solid ${accent}`, borderRadius: 14, padding: '1.1rem 1.25rem' }),
  statIcon:   (accent, bg) => ({ width: 36, height: 36, borderRadius: 9, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '0.75rem', color: accent, fontSize: '0.95rem' }),
  statValue:  { fontSize: '1.65rem', fontWeight: 700, color: '#f0f6fc', lineHeight: 1, marginBottom: 3 },
  statLabel:  { fontSize: '0.72rem', color: '#6e7681', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 },

  toolbar:    { display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap', alignItems: 'center' },
  searchWrap: { flex: 1, minWidth: 200, position: 'relative' },
  searchIcon: { position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#6e7681', fontSize: '0.85rem', pointerEvents: 'none' },
  input:      { width: '100%', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', padding: '0.48rem 0.75rem 0.48rem 2rem', fontSize: '0.85rem', outline: 'none', boxSizing: 'border-box' },
  select:     { background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', padding: '0.48rem 0.75rem', fontSize: '0.85rem', outline: 'none', cursor: 'pointer', minWidth: 130 },

  card:       { background: '#161b22', border: '1px solid #21262d', borderRadius: 14, overflow: 'hidden' },
  cardHeader: { padding: '0.9rem 1.25rem', borderBottom: '1px solid #21262d', display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
  cardTitle:  { margin: 0, fontSize: '0.88rem', fontWeight: 600, color: '#f0f6fc' },

  badge: (bg, color) => ({ display: 'inline-block', padding: '0.18em 0.6em', borderRadius: 20, fontSize: '0.7rem', fontWeight: 600, background: bg, color }),

  primaryBtn: { padding: '0.48rem 1.1rem', background: 'linear-gradient(135deg,#7c3aed,#5b21b6)', color: '#fff', border: 'none', borderRadius: 8, fontSize: '0.83rem', fontWeight: 600, cursor: 'pointer', fontFamily: "'DM Sans',sans-serif", whiteSpace: 'nowrap' },
  ghostBtn:   { padding: '0.48rem 1rem', background: 'transparent', color: '#8b949e', border: '1px solid #30363d', borderRadius: 8, fontSize: '0.83rem', cursor: 'pointer', fontFamily: "'DM Sans',sans-serif" },
  dangerBtn:  { padding: '0.42rem 0.85rem', background: 'transparent', color: '#f87171', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 7, fontSize: '0.78rem', cursor: 'pointer', fontFamily: "'DM Sans',sans-serif" },

  avatar: (i) => {
    const colors = [['#7c3aed','#5b21b6'],['#10b981','#059669'],['#3b82f6','#1d4ed8'],['#f59e0b','#d97706'],['#ef4444','#b91c1c']]
    const [a, b] = colors[i % colors.length]
    return { width: 36, height: 36, borderRadius: 9, background: `linear-gradient(135deg,${a},${b})`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: 700, color: '#fff', flexShrink: 0 }
  },

  formLabel:  { display: 'block', fontSize: '0.75rem', color: '#6e7681', marginBottom: 4, fontWeight: 500 },
  formInput:  { width: '100%', background: '#0d1117', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', padding: '0.48rem 0.75rem', fontSize: '0.83rem', outline: 'none', marginBottom: '0.85rem', boxSizing: 'border-box' },
  formSelect: { width: '100%', background: '#0d1117', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', padding: '0.48rem 0.75rem', fontSize: '0.83rem', outline: 'none', marginBottom: '0.85rem', cursor: 'pointer', boxSizing: 'border-box' },

  overlay:    { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(4px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' },
  modal:      { background: '#161b22', border: '1px solid #30363d', borderRadius: 16, width: '100%', maxWidth: 560, maxHeight: '90vh', overflowY: 'auto' },
  modalHead:  { padding: '1rem 1.25rem', borderBottom: '1px solid #21262d', display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
  modalTitle: { margin: 0, fontSize: '0.95rem', fontWeight: 600, color: '#f0f6fc' },
  modalBody:  { padding: '1.25rem' },
  closeBtn:   { background: 'transparent', border: 'none', color: '#6e7681', cursor: 'pointer', fontSize: '1.1rem', padding: '0 4px', lineHeight: 1 },

  formGrid2:  { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 0.85rem' },

  spinner:    { display: 'inline-block', width: 26, height: 26, border: '2.5px solid #21262d', borderTopColor: '#7c3aed', borderRadius: '50%', animation: 'spin 0.7s linear infinite' },
  emptyWrap:  { textAlign: 'center', padding: '3rem 1rem', color: '#6e7681', fontSize: '0.83rem' },

  detailRow:  { display: 'flex', justifyContent: 'space-between', padding: '0.55rem 0', borderBottom: '1px solid #21262d' },
  detailLabel:{ fontSize: '0.76rem', color: '#6e7681' },
  detailValue:{ fontSize: '0.8rem', color: '#e6edf3', fontWeight: 500, textAlign: 'right' },
}

const STATUS_COLORS = {
  active:     { bg: 'rgba(16,185,129,0.12)',  color: '#34d399' },
  inactive:   { bg: 'rgba(100,116,139,0.12)', color: '#94a3b8' },
  on_leave:   { bg: 'rgba(245,158,11,0.12)',  color: '#fbbf24' },
  terminated: { bg: 'rgba(239,68,68,0.12)',   color: '#f87171' },
}

const EMPTY_FORM = {
  userId: '', firstName: '', lastName: '', email: '', phone: '',
  title: '', department: '', employmentType: 'full_time', salary: '',
  status: 'active', hireDate: new Date().toISOString().split('T')[0],
}

export default function EmployeesPage() {
  const user = useSelector(s => s.auth.user)

  // ── state ──────────────────────────────────────────────────────────────────
  const [employees,   setEmployees]   = useState([])
  const [stats,       setStats]       = useState(null)
  const [departments, setDepartments] = useState([])
  const [loading,     setLoading]     = useState(true)
  const [submitting,  setSubmitting]  = useState(false)

  // filters
  const [search,  setSearch]  = useState('')
  const [deptFilter, setDept] = useState('')
  const [statusFilter, setStatus] = useState('')
  const [page, setPage]       = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  // modals
  const [showAdd,    setShowAdd]    = useState(false)
  const [showDetail, setShowDetail] = useState(null)  // employee object
  const [showEdit,   setShowEdit]   = useState(null)  // employee object

  const [form, setForm] = useState(EMPTY_FORM)
  const setF = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  // ── load ───────────────────────────────────────────────────────────────────
  const load = async (p = 1) => {
    setLoading(true)
    try {
      const params = { page: p, limit: 10 }
      if (search)       params.search     = search
      if (deptFilter)   params.department = deptFilter
      if (statusFilter) params.status     = statusFilter

      const [er, sr, dr] = await Promise.allSettled([
        employeeAPI.getAll(params),
        employeeAPI.getStats(),
        departmentAPI.getAll(),
      ])
      if (er.status === 'fulfilled') {
        setEmployees(er.value.data.employees || [])
        setTotalPages(er.value.data.pagination?.pages || 1)
      }
      if (sr.status === 'fulfilled') setStats(sr.value.data)
      if (dr.status === 'fulfilled') setDepartments(dr.value.data.departments || [])
    } catch { toast.error('Failed to load employees') }
    finally { setLoading(false) }
  }

  useEffect(() => { load(1) }, [search, deptFilter, statusFilter])

  // ── add employee ───────────────────────────────────────────────────────────
  const handleAdd = async () => {
    if (!form.userId || !form.firstName || !form.lastName || !form.email) {
      return toast.error('User ID, first name, last name and email are required')
    }
    setSubmitting(true)
    try {
      await employeeAPI.create({
        user: form.userId,
        personalInfo: { firstName: form.firstName, lastName: form.lastName, email: form.email, phone: form.phone },
        jobInfo:      { title: form.title, department: form.department || undefined, employmentType: form.employmentType, salary: Number(form.salary) || 0, hireDate: form.hireDate },
        status: form.status,
      })
      toast.success('Employee added successfully!')
      setShowAdd(false)
      setForm(EMPTY_FORM)
      load(1)
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to add employee') }
    finally { setSubmitting(false) }
  }

  // ── update employee ────────────────────────────────────────────────────────
  const handleUpdate = async () => {
    setSubmitting(true)
    try {
      await employeeAPI.update(showEdit._id, {
        personalInfo: { firstName: form.firstName, lastName: form.lastName, email: form.email, phone: form.phone },
        jobInfo:      { title: form.title, department: form.department || undefined, employmentType: form.employmentType, salary: Number(form.salary) || 0, hireDate: form.hireDate },
        status: form.status,
      })
      toast.success('Employee updated!')
      setShowEdit(null)
      load(page)
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to update') }
    finally { setSubmitting(false) }
  }

  const openEdit = (emp) => {
    setForm({
      userId:         emp.user?._id || '',
      firstName:      emp.personalInfo?.firstName || '',
      lastName:       emp.personalInfo?.lastName  || '',
      email:          emp.personalInfo?.email     || '',
      phone:          emp.personalInfo?.phone     || '',
      title:          emp.jobInfo?.title          || '',
      department:     emp.jobInfo?.department?._id || '',
      employmentType: emp.jobInfo?.employmentType  || 'full_time',
      salary:         emp.jobInfo?.salary          || '',
      status:         emp.status                   || 'active',
      hireDate:       emp.jobInfo?.hireDate ? new Date(emp.jobInfo.hireDate).toISOString().split('T')[0] : '',
    })
    setShowEdit(emp)
  }

  // ── render ─────────────────────────────────────────────────────────────────
  const EmployeeForm = ({ onSave, onCancel, isEdit }) => (
    <div style={S.modalBody}>
      {!isEdit && (
        <>
          <label style={S.formLabel}>Auth User ID <span style={{ color: '#f87171' }}>*</span></label>
          <input style={S.formInput} value={form.userId} onChange={setF('userId')} placeholder="MongoDB _id from Passwordmodel" />
          <div style={{ fontSize: '0.72rem', color: '#6e7681', marginTop: -10, marginBottom: '0.85rem' }}>
            The _id of the registered user this employee belongs to
          </div>
        </>
      )}

      <div style={S.formGrid2}>
        <div>
          <label style={S.formLabel}>First Name <span style={{ color: '#f87171' }}>*</span></label>
          <input style={S.formInput} value={form.firstName} onChange={setF('firstName')} placeholder="Aditya" />
        </div>
        <div>
          <label style={S.formLabel}>Last Name <span style={{ color: '#f87171' }}>*</span></label>
          <input style={S.formInput} value={form.lastName} onChange={setF('lastName')} placeholder="Bisht" />
        </div>
      </div>

      <label style={S.formLabel}>Email <span style={{ color: '#f87171' }}>*</span></label>
      <input style={S.formInput} type="email" value={form.email} onChange={setF('email')} placeholder="aditya@company.com" />

      <div style={S.formGrid2}>
        <div>
          <label style={S.formLabel}>Phone</label>
          <input style={S.formInput} value={form.phone} onChange={setF('phone')} placeholder="+91 00000 00000" />
        </div>
        <div>
          <label style={S.formLabel}>Job Title</label>
          <input style={S.formInput} value={form.title} onChange={setF('title')} placeholder="Software Engineer" />
        </div>
      </div>

      <div style={S.formGrid2}>
        <div>
          <label style={S.formLabel}>Department</label>
          <select style={S.formSelect} value={form.department} onChange={setF('department')}>
            <option value="">No Department</option>
            {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
          </select>
        </div>
        <div>
          <label style={S.formLabel}>Employment Type</label>
          <select style={S.formSelect} value={form.employmentType} onChange={setF('employmentType')}>
            <option value="full_time">Full Time</option>
            <option value="part_time">Part Time</option>
            <option value="contract">Contract</option>
            <option value="intern">Intern</option>
          </select>
        </div>
      </div>

      <div style={S.formGrid2}>
        <div>
          <label style={S.formLabel}>Salary (₹/month)</label>
          <input style={S.formInput} type="number" value={form.salary} onChange={setF('salary')} placeholder="50000" />
        </div>
        <div>
          <label style={S.formLabel}>Hire Date</label>
          <input style={S.formInput} type="date" value={form.hireDate} onChange={setF('hireDate')} />
        </div>
      </div>

      <label style={S.formLabel}>Status</label>
      <select style={S.formSelect} value={form.status} onChange={setF('status')}>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
        <option value="on_leave">On Leave</option>
        <option value="terminated">Terminated</option>
      </select>

      <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
        <button style={S.ghostBtn} onClick={onCancel}>Cancel</button>
        <button style={S.primaryBtn} onClick={onSave} disabled={submitting}>
          {submitting ? 'Saving…' : isEdit ? 'Update Employee' : 'Add Employee'}
        </button>
      </div>
    </div>
  )

  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        .emp-row:hover td { background: rgba(255,255,255,0.025) !important; }
        .emp-search:focus { border-color: #7c3aed !important; }
        .emp-select:focus { border-color: #7c3aed !important; }
        .page-btn:hover { border-color: #7c3aed !important; color: #a78bfa !important; }
      `}</style>

      <div style={S.page}>

        {/* ── Header ── */}
        <div style={S.header}>
          <div>
            <h4 style={S.title}>Employee Management</h4>
            <p style={S.sub}>Manage your organisation's workforce</p>
          </div>
          <button style={S.primaryBtn} onClick={() => { setForm(EMPTY_FORM); setShowAdd(true) }}>
            ＋ Add Employee
          </button>
        </div>

        {/* ── Stat Cards ── */}
        <div style={S.grid4}>
          {[
            { label: 'Total Employees', value: stats?.totalEmployees,  accent: '#7c3aed', bg: 'rgba(124,58,237,0.12)', icon: '👥' },
            { label: 'Active',          value: stats?.activeEmployees,  accent: '#34d399', bg: 'rgba(16,185,129,0.12)',  icon: '✅' },
            { label: 'On Leave',        value: stats?.onLeave,          accent: '#fbbf24', bg: 'rgba(245,158,11,0.12)',  icon: '🏖️' },
            { label: 'New This Month',  value: stats?.newThisMonth,     accent: '#60a5fa', bg: 'rgba(59,130,246,0.12)',  icon: '🆕' },
          ].map(c => (
            <div key={c.label} style={S.statCard(c.accent, c.bg)}>
              <div style={S.statIcon(c.accent, c.bg)}>{c.icon}</div>
              <div style={S.statValue}>{loading ? '…' : (c.value ?? '—')}</div>
              <div style={S.statLabel}>{c.label}</div>
            </div>
          ))}
        </div>

        {/* ── Toolbar ── */}
        <div style={S.toolbar}>
          <div style={S.searchWrap}>
            <span style={S.searchIcon}>🔍</span>
            <input
              className="emp-search"
              style={S.input}
              placeholder="Search by name, email, code…"
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
            />
          </div>
          <select className="emp-select" style={S.select} value={deptFilter} onChange={e => { setDept(e.target.value); setPage(1) }}>
            <option value="">All Departments</option>
            {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
          </select>
          <select className="emp-select" style={S.select} value={statusFilter} onChange={e => { setStatus(e.target.value); setPage(1) }}>
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="on_leave">On Leave</option>
            <option value="terminated">Terminated</option>
          </select>
        </div>

        {/* ── Table ── */}
        <div style={S.card}>
          <div style={S.cardHeader}>
            <p style={S.cardTitle}>All Employees</p>
            <span style={S.badge('rgba(100,116,139,0.12)', '#94a3b8')}>
              {employees.length} shown
            </span>
          </div>

          {loading ? (
            <div style={S.emptyWrap}><div style={S.spinner} /></div>
          ) : employees.length === 0 ? (
            <div style={S.emptyWrap}>No employees found.</div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                <thead>
                  <tr>
                    {['Employee', 'Code', 'Department', 'Title', 'Type', 'Status', 'Joined', 'Actions'].map(h => (
                      <th key={h} style={{ padding: '0.7rem 1rem', textAlign: 'left', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#6e7681', borderBottom: '1px solid #21262d', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {employees.map((emp, i) => {
                    const sc = STATUS_COLORS[emp.status] || STATUS_COLORS.inactive
                    return (
                      <tr key={emp._id} className="emp-row">
                        <td style={{ padding: '0.7rem 1rem', borderBottom: '1px solid #21262d' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={S.avatar(i)}>{initials(emp.personalInfo?.firstName, emp.personalInfo?.lastName)}</div>
                            <div>
                              <div style={{ fontWeight: 600, color: '#f0f6fc' }}>
                                {emp.personalInfo?.firstName} {emp.personalInfo?.lastName}
                              </div>
                              <div style={{ fontSize: '0.72rem', color: '#6e7681' }}>{emp.personalInfo?.email}</div>
                            </div>
                          </div>
                        </td>
                        <td style={{ padding: '0.7rem 1rem', color: '#a78bfa', fontFamily: 'monospace', fontSize: '0.8rem', borderBottom: '1px solid #21262d' }}>{emp.employeeCode || '—'}</td>
                        <td style={{ padding: '0.7rem 1rem', color: '#c9d1d9', borderBottom: '1px solid #21262d' }}>{emp.jobInfo?.department?.name || '—'}</td>
                        <td style={{ padding: '0.7rem 1rem', color: '#c9d1d9', borderBottom: '1px solid #21262d' }}>{emp.jobInfo?.title || '—'}</td>
                        <td style={{ padding: '0.7rem 1rem', borderBottom: '1px solid #21262d' }}>
                          <span style={S.badge('rgba(59,130,246,0.1)', '#60a5fa')}>
                            {emp.jobInfo?.employmentType?.replace('_', ' ') || '—'}
                          </span>
                        </td>
                        <td style={{ padding: '0.7rem 1rem', borderBottom: '1px solid #21262d' }}>
                          <span style={S.badge(sc.bg, sc.color)}>{emp.status}</span>
                        </td>
                        <td style={{ padding: '0.7rem 1rem', color: '#6e7681', fontSize: '0.78rem', borderBottom: '1px solid #21262d', whiteSpace: 'nowrap' }}>{fmt(emp.jobInfo?.hireDate)}</td>
                        <td style={{ padding: '0.7rem 1rem', borderBottom: '1px solid #21262d' }}>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button
                              style={{ ...S.ghostBtn, padding: '0.3rem 0.7rem', fontSize: '0.75rem' }}
                              onClick={() => setShowDetail(emp)}
                            >View</button>
                            <button
                              style={{ ...S.ghostBtn, padding: '0.3rem 0.7rem', fontSize: '0.75rem', color: '#a78bfa', borderColor: 'rgba(124,58,237,0.3)' }}
                              onClick={() => openEdit(emp)}
                            >Edit</button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '1rem' }}>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button
                  key={p}
                  className="page-btn"
                  onClick={() => { setPage(p); load(p) }}
                  style={{ width: 32, height: 32, borderRadius: 7, border: '1px solid #30363d', background: page === p ? 'rgba(124,58,237,0.2)' : 'transparent', color: page === p ? '#a78bfa' : '#6e7681', cursor: 'pointer', fontSize: '0.82rem', fontFamily: "'DM Sans',sans-serif" }}
                >{p}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Add Employee Modal ── */}
      {showAdd && (
        <div style={S.overlay} onClick={e => e.target === e.currentTarget && setShowAdd(false)}>
          <div style={S.modal}>
            <div style={S.modalHead}>
              <p style={S.modalTitle}>Add New Employee</p>
              <button style={S.closeBtn} onClick={() => setShowAdd(false)}>✕</button>
            </div>
            <EmployeeForm onSave={handleAdd} onCancel={() => setShowAdd(false)} isEdit={false} />
          </div>
        </div>
      )}

      {/* ── Edit Employee Modal ── */}
      {showEdit && (
        <div style={S.overlay} onClick={e => e.target === e.currentTarget && setShowEdit(null)}>
          <div style={S.modal}>
            <div style={S.modalHead}>
              <p style={S.modalTitle}>Edit — {showEdit.personalInfo?.firstName} {showEdit.personalInfo?.lastName}</p>
              <button style={S.closeBtn} onClick={() => setShowEdit(null)}>✕</button>
            </div>
            <EmployeeForm onSave={handleUpdate} onCancel={() => setShowEdit(null)} isEdit={true} />
          </div>
        </div>
      )}

      {/* ── View Detail Modal ── */}
      {showDetail && (
        <div style={S.overlay} onClick={e => e.target === e.currentTarget && setShowDetail(null)}>
          <div style={S.modal}>
            <div style={S.modalHead}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ ...S.avatar(0), width: 40, height: 40 }}>
                  {initials(showDetail.personalInfo?.firstName, showDetail.personalInfo?.lastName)}
                </div>
                <div>
                  <p style={S.modalTitle}>{showDetail.personalInfo?.firstName} {showDetail.personalInfo?.lastName}</p>
                  <div style={{ fontSize: '0.72rem', color: '#6e7681' }}>{showDetail.employeeCode}</div>
                </div>
              </div>
              <button style={S.closeBtn} onClick={() => setShowDetail(null)}>✕</button>
            </div>
            <div style={S.modalBody}>
              {[
                { label: 'Email',           value: showDetail.personalInfo?.email },
                { label: 'Phone',           value: showDetail.personalInfo?.phone || '—' },
                { label: 'Job Title',       value: showDetail.jobInfo?.title || '—' },
                { label: 'Department',      value: showDetail.jobInfo?.department?.name || '—' },
                { label: 'Employment Type', value: showDetail.jobInfo?.employmentType?.replace('_', ' ') || '—' },
                { label: 'Salary',          value: showDetail.jobInfo?.salary ? `₹${Number(showDetail.jobInfo.salary).toLocaleString('en-IN')}` : '—' },
                { label: 'Status',          value: showDetail.status },
                { label: 'Hire Date',       value: fmt(showDetail.jobInfo?.hireDate) },
                { label: 'Performance',     value: showDetail.performanceScore ? `${showDetail.performanceScore}/100` : '—' },
                { label: 'Auth Role',       value: showDetail.user?.role || '—' },
              ].map(({ label, value }) => (
                <div key={label} style={S.detailRow}>
                  <span style={S.detailLabel}>{label}</span>
                  <span style={S.detailValue}>{value}</span>
                </div>
              ))}
              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.25rem', justifyContent: 'flex-end' }}>
                <button style={S.ghostBtn} onClick={() => setShowDetail(null)}>Close</button>
                <button style={{ ...S.ghostBtn, color: '#a78bfa', borderColor: 'rgba(124,58,237,0.3)' }}
                  onClick={() => { setShowDetail(null); openEdit(showDetail) }}>
                  Edit Employee
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
